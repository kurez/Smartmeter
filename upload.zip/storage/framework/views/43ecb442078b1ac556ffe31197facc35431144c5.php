<head>
   <meta charset="utf-8">
   <meta name="author" content="Softnio">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="Fully featured and complete ICO Dashboard template for ICO backend management.">
   <!-- Fav Icon -->
   <link rel="shortcut icon" href="images/favicon.png">
   <!-- Site Title  -->
   <title><?php echo $__env->yieldContent('title'); ?> | Smart Meter</title>
   <!-- Vendor Bundle CSS -->
   <link rel="stylesheet" href="<?php echo asset('assets/css/vendor.bundle.css'); ?>">
   <!-- Custom styles for this template -->
   <link rel="stylesheet" href="<?php echo asset('assets/css/style.css'); ?>" id="layoutstyle">
</head>
<?php /**PATH /opt/lampp/htdocs/devint/smart-meter/resources/views/partials/_head.blade.php ENDPATH**/ ?>